//***********************************************************
//   Lab4point1E.java
//   Computes total boxes sold during a campaign that is “n” weeks long         
//***********************************************************

import static java.lang.System.out;
import java.util.Random;

public class Lab4point1E
{
    public static void main(String[] args)
    {

		
	}

