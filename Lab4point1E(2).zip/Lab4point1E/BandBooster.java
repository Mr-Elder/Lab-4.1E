// ****************************************************************
//   BandBooster.java
//
//   Write the BandBooster class assuming a band booster object
//   is described by two pieces of instance data: name (a string)
//   and boxesSold (an integer)
// ****************************************************************
import static java.lang.System.out;
import java.util.Random;

public class BandBooster
{
    //declare instance data 

    //constructor
    public BandBooster(String boosterName)
    {
    }


	public String getName()
  	{
  	}

    public void updateSales(int nbrOfBoxes)
    {
    }

	public String toString()
  	{
  	}


}
